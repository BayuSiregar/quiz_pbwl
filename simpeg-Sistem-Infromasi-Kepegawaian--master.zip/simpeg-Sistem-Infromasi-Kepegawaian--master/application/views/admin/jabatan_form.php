<table class="table table-reposive">
	<form action="" method="POST">
	<tr><th>Nama Jabatan</th><td><input type="text" name="nama_jabatan" class="form-control" value="<?= $nama_jabatan ?>"></td></tr>
	<tr><th>Golongan</th><td><input type="text" name="golongan" class="form-control" value="<?= $golongan ?>"></td></tr>
	<tr><th>Jumlah Tunjangan</th><td><input type="number" name="tunjangan" class="form-control" value="<?= $tunjangan ?>"></td></tr>
    <tr><td></td><th><input type="submit" name="kirim" value="Submit" class="btn btn-primary"></th></tr>
    </form>	 
</table>
 
 